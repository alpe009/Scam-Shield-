# ScamShield 4.2 Android Package Lock

Status: LOCKED

- App name: ScamShield
- Package / applicationId: `com.scamshield.security`
- Version name: `4.2.0`
- Version code: `42001`
- Namespace: `com.scamshield.security`
- Target/compile API: 36

Important: Google Play treats package names as unique and permanent for an app. This package ID must be used consistently in every future ScamShield Android release.

Before first publication, register/create the app with this package name in the owner's Google Play Console and complete any Android developer verification/package-name registration steps shown there.

Do not change the applicationId after the first Play upload.
