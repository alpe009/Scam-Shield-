# ScamShield — Google Play Store Listing

## App name
ScamShield

## Short description
Check suspicious messages, links, phone numbers, UPI IDs and QR destinations before you trust or pay.

## Full description
ScamShield is a defensive anti-fraud assistant designed to help you spot common scam indicators before you share sensitive information or send money.

Features include:
- Suspicious message analysis
- Link and website indicator checks
- Phone-number and UPI-ID checks
- QR destination scanning
- Case history on the device
- Fraud recovery guidance
- Personal-data protection guidance

ScamShield does not ask for OTPs, UPI PINs, CVVs, card PINs or banking passwords.

Important: ScamShield provides indicators and safety guidance, not a guarantee that a person, message, website or payment is safe. Always verify independently through an official channel.
