# ScamShield 4.2 Google Play release structure

## Required before upload
- [ ] Create the ScamShield app in Play Console.
- [ ] Register/confirm the final Android package name.
- [ ] Complete developer identity verification.
- [ ] Configure Play App Signing.
- [ ] Build a signed Android App Bundle (`.aab`).
- [ ] Complete Data safety and privacy declarations based on the final implementation.
- [ ] Provide a valid privacy-policy URL.
- [ ] Complete content rating and target audience declarations.
- [ ] Declare any sensitive permissions if applicable.
- [ ] Add store icon, feature graphic, screenshots, short/full descriptions.
- [ ] Run internal testing before production.

## Release tracks
1. Internal testing
2. Closed testing
3. Open testing (optional)
4. Production

## Suggested artifact naming
`ScamShield-4.2.0-42001-release.aab`
