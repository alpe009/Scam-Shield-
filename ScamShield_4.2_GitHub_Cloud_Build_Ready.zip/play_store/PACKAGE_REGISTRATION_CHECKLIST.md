# Google Play Package Registration Checklist

Package: `com.scamshield.security`

1. Sign in to the owner's Google Play Console.
2. Complete developer identity verification if requested.
3. Create ScamShield using package/application ID `com.scamshield.security`.
4. If Play Console shows Android developer package registration, register this package and add the public certificate from the ScamShield upload key.
5. Enable Play App Signing when creating the first production release.
6. Upload only the signed ScamShield AAB produced from this project.
7. Keep the private upload keystore and passwords offline and backed up securely.
8. Never change the package name for future ScamShield updates.
