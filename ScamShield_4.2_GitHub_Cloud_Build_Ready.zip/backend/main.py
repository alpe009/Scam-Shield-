from fastapi import FastAPI
from pydantic import BaseModel
import re

app = FastAPI(title="ScamShield API", version="2.0")

class AnalyzeRequest(BaseModel):
    type: str
    value: str

def analyze(v: str):
    s=v.lower()
    reasons=[]
    for w in ["otp","upi pin","cvv","password","urgent","kyc","account blocked","click now","pay now","refund fee","prize","lottery","arrest"]:
        if w in s: reasons.append(f"Possible scam indicator: {w}")
    if re.search(r"https?://|www\.", s):
        reasons.append("Contains a link; verify its destination.")
    if len(reasons)>=3:
        return {"risk":"high","title":"High risk","explanation":"Do not share secrets or send money.", "reasons":reasons}
    if reasons:
        return {"risk":"suspicious","title":"Suspicious","explanation":"Verify independently using an official channel.", "reasons":reasons}
    return {"risk":"safe","title":"No obvious red flags","explanation":"No common rule-based pattern was found. This is not a guarantee of safety.","reasons":["No strong local indicators."]}

@app.get("/health")
def health(): return {"status":"ok"}

@app.post("/analyze")
def analyze_request(req: AnalyzeRequest):
    return analyze(req.value)
