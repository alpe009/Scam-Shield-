# ScamShield 4.2 — GitHub Cloud Build Setup

## Repository layout
The repository root contains `ScamShield_Release/`. The Flutter project is under `ScamShield_Release/flutter_app/`.

Locked Android identity:
- Application ID: `com.scamshield.security`
- Version: `4.2.0`
- Version code: `42001`
- Target/compile SDK: 36

## 1. Create the GitHub repository
Create a new private repository, for example `scamshield-4.2`.
Do not upload any `.jks`, `.keystore`, `key.properties`, passwords, or service-account JSON.

From this package directory:
```bash
git init
git add .
git commit -m "ScamShield 4.2 release"
git branch -M main
git remote add origin <YOUR_PRIVATE_GITHUB_REPO_URL>
git push -u origin main
```

## 2. Add GitHub Actions secrets
Repository → Settings → Secrets and variables → Actions → New repository secret.

Required for signed releases:
- `ANDROID_KEYSTORE_BASE64` — base64 of the private upload keystore
- `ANDROID_KEYSTORE_PASSWORD` — keystore password
- `ANDROID_KEY_ALIAS` — upload key alias
- `ANDROID_KEY_PASSWORD` — key password

Optional:
- `API_BASE_URL` — production backend URL. Leave unset if ScamShield should use its local rule-based analysis.

The workflow never writes these secrets to the repository.

## 3. Create the keystore secret safely
On a trusted computer where the private keystore exists:
```bash
base64 -w 0 scamshield-upload.jks
```
Copy the resulting single-line value into `ANDROID_KEYSTORE_BASE64`.

On macOS, use:
```bash
base64 < scamshield-upload.jks | tr -d '\n'
```

## 4. Cloud build
Go to GitHub → Actions → `ScamShield Android Release` → Run workflow.

The workflow:
1. checks out the code;
2. installs Flutter 3.47.4 and Java 17;
3. runs `flutter pub get` and `flutter analyze`;
4. reconstructs the private upload keystore only inside the ephemeral runner;
5. builds a signed Android App Bundle;
6. publishes the `.aab` as a short-retention GitHub Actions artifact.

It does not commit or permanently store the signing key.

## 5. Tag-based release
After validation:
```bash
git tag v4.2.0
git push origin v4.2.0
```
This also triggers the release workflow.

## 6. Play Console
Upload:
`ScamShield-4.2.0-42001-release.aab`

Use Google Play App Signing. The private keystore in GitHub is the upload key, not a key that should be exposed publicly.

## Important lock
Do not change `applicationId` after the first Play upload. If `com.scamshield.security` is unavailable/incorrect for the publisher, resolve that before the first production upload.
