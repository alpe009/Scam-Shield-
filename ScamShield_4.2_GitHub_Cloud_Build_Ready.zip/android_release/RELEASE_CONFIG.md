# ScamShield 4.2 Android release configuration

Provisional application ID: `com.scamshield.security`
Version name: `4.2.0`
Version code: `42001`
Compile SDK: 36
Target SDK: 36
Minimum SDK: 24

IMPORTANT: The application ID must be owned/registered by the publisher before Play submission. If this identifier is not available to you, replace it everywhere before the first production upload.

Release signing must use the publisher's private upload keystore. Never place passwords, `.jks`/`.keystore` files, or service-account credentials in source control.
