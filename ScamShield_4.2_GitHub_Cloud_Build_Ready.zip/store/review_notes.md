# App Review Notes

ScamShield is a defensive anti-fraud application.

Core user flow:
1. User chooses Phone, Message, Link, UPI or QR check.
2. User voluntarily supplies the item.
3. The app returns a risk assessment and explains warning signs.
4. Recovery provides guidance for contacting the user's own bank/payment provider and official reporting channels.

The app does not:
- access another person's accounts
- bypass authentication
- steal credentials
- take money
- collect OTPs, PINs, CVVs or passwords

QR scanning requires camera access only when the user chooses Scan QR.
