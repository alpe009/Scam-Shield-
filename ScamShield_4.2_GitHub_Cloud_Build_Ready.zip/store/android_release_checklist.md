# Google Play release checklist

- Set a unique applicationId/package name owned by the publisher.
- Build an Android App Bundle (.aab), not an APK for normal Play release.
- Target Android 16 / API 36 or higher for new submissions and updates as of Aug 31, 2026.
- Configure release signing and keep the signing key secure.
- Complete Play Console app content declarations.
- Complete Data safety disclosures accurately.
- Publish a privacy policy URL.
- Prepare screenshots, icon, feature graphic and store listing.
- Test on supported Android versions and physical devices.
- Verify camera permission wording and behavior.
- Verify that all external links use HTTPS.
- Run security/dependency scans.
