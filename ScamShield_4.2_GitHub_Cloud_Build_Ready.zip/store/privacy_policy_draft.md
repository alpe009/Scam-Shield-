# ScamShield Privacy Policy — Draft

Last updated: [DATE]

ScamShield is designed around data minimization.

## Information processed
The app may process information you voluntarily submit for a check, such as a phone number, message, URL, QR destination or payment identifier. In the current local-only mode, check history is stored on the device.

If a future cloud service is enabled, submitted content may be transmitted to our secure server to provide fraud analysis. Before enabling such a service, the production app must disclose the categories of data, purposes, retention period, service providers and deletion process.

## Sensitive information
ScamShield should never request OTPs, UPI PINs, card PINs, CVVs, banking passwords or account recovery secrets.

## Sharing
We do not sell personal information. Any third-party fraud-intelligence or AI provider used in production must be disclosed before data is shared and must have appropriate contractual/privacy protections.

## Security
We use reasonable technical and organizational safeguards. No system can guarantee absolute security.

## Retention and deletion
Local history can be cleared by the user. For cloud accounts, users will be provided a clear deletion mechanism and applicable retention information.

## Contact
[LEGAL ENTITY]
[SUPPORT EMAIL]
[PRIVACY EMAIL]

This is a template and must be reviewed and completed by the publisher/legal adviser before publication.
