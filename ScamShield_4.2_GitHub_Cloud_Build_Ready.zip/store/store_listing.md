# ScamShield — Store Listing Draft

## App name
ScamShield

## Short description
Check suspicious messages, links, QR codes and payment requests before you trust or pay.

## Full description
ScamShield is a personal anti-fraud assistant designed to help you identify common scam warning signs and respond quickly when fraud happens.

FEATURES
• Check suspicious messages and scam language
• Check phone numbers and payment identifiers
• Analyze website links before opening them
• Scan QR codes and review their destination
• Protect sensitive information such as OTPs, PINs, CVV and passwords
• Preserve a simple local history of checks
• Follow a step-by-step fraud recovery checklist
• Open official cybercrime reporting resources

IMPORTANT
ScamShield does not access, control or take money from another person's account. It does not ask for your banking password, OTP, UPI PIN, CVV or card PIN. Results are risk indicators, not guarantees.

For financial loss, contact your bank/payment provider and the appropriate authorities immediately.
