# Apple App Store release checklist

- Use a unique Bundle ID.
- Configure signing, certificates and App Store provisioning.
- Add NSCameraUsageDescription for QR scanning.
- Add an accessible privacy policy in the app and App Store metadata.
- Complete App Store Connect App Privacy accurately.
- If accounts are added, provide account deletion in the app.
- Prepare screenshots, app icon, description, keywords and support URL.
- Test on physical iPhone/iPad devices.
- Provide App Review notes explaining non-obvious functionality.
- Ensure production backend services are live during review.
- Submit through TestFlight before final review.
