# Build ScamShield 4.2 Android

1. Install Flutter and Android SDK/Android Studio.
2. From `flutter_app/`, run `flutter create . --platforms=android` if the generated Flutter Android wrapper is required by your installed Flutter version. Preserve the package/applicationId/target settings from this release configuration.
3. Run `flutter pub get`.
4. Run `flutter analyze`.
5. Run `flutter test`.
6. Configure the private upload keystore.
7. Build: `flutter build appbundle --release --dart-define=API_BASE_URL=https://YOUR-DOMAIN`.
8. Verify the generated `.aab` and upload it to Play Console internal testing.

Do not commit signing credentials.
