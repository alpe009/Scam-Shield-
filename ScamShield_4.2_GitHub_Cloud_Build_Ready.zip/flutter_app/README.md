# ScamShield 4.2

Defensive anti-fraud assistant. The app lets users voluntarily check suspicious messages, phone numbers, links, UPI IDs and QR destinations, then provides risk indicators and recovery guidance.

## Build

1. Install Flutter 3.x and Android/iOS toolchains.
2. Run `flutter pub get`.
3. Set a production backend with `--dart-define=API_BASE_URL=https://YOUR-DOMAIN` if desired. Leave unset for local rule-based analysis.
4. Set the Android application ID / iOS Bundle ID to an identifier owned by the publisher.
5. Configure release signing and store metadata before submission.

## Android

Build an App Bundle with:
`flutter build appbundle --release`

For a 2026 Play submission, verify the current target API requirement in Play Console and use API 36 or newer as applicable.

## iOS

Open the generated Flutter iOS project in Xcode, set signing/team and the unique Bundle ID, add the required camera usage description for QR scanning, then archive for App Store Connect.

## Important

This package contains source and release documentation; it does not contain publisher signing keys or a store-signed binary. The privacy policy and store listing still require the publisher's legal/support details before submission.
