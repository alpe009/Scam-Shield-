import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

const apiBaseUrl = String.fromEnvironment('API_BASE_URL', defaultValue: '');

void main() => runApp(const ScamShield());

enum Risk { safe, suspicious, high }

class Result {
  final Risk risk;
  final String title;
  final String explanation;
  final List<String> reasons;
  const Result(this.risk, this.title, this.explanation, this.reasons);
}

Result localAnalyze(String text) {
  final s=text.toLowerCase();
  final reasons=<String>[];
  for (final w in ['otp','upi pin','cvv','password','urgent','kyc','account blocked','click now','pay now','refund fee','prize','lottery','arrest']) {
    if(s.contains(w)) reasons.add('Possible scam indicator: $w');
  }
  if(RegExp(r'https?://|www\.').hasMatch(s)) reasons.add('Contains a link; verify its destination.');
  if(reasons.length>=3) return Result(Risk.high,'High risk','Do not share secrets or send money.',reasons);
  if(reasons.isNotEmpty) return Result(Risk.suspicious,'Suspicious','Verify independently using an official channel.',reasons);
  return const Result(Risk.safe,'No obvious red flags','No common local pattern was found. This is not a guarantee of safety.',['No strong local indicators.']);
}

Future<Result> analyze(String type,String value) async {
  if(apiBaseUrl.isEmpty) return localAnalyze(value);
  try {
    final r=await http.post(Uri.parse('$apiBaseUrl/analyze'),
      headers:{'Content-Type':'application/json'},
      body:jsonEncode({'type':type,'value':value})).timeout(const Duration(seconds:8));
    if(r.statusCode==200) {
      final j=jsonDecode(r.body);
      return Result(Risk.values.firstWhere((x)=>x.name==j['risk'],orElse:()=>Risk.suspicious),
        j['title']??'Result',j['explanation']??'',List<String>.from(j['reasons']??[]));
    }
  } catch (_) {}
  return localAnalyze(value);
}

class ScamShield extends StatelessWidget {
  const ScamShield({super.key});
  @override Widget build(BuildContext c)=>MaterialApp(
    debugShowCheckedModeBanner:false,title:'ScamShield',
    theme:ThemeData(useMaterial3:true,colorSchemeSeed:Colors.indigo),
    home:const Home());
}

class Home extends StatefulWidget { const Home({super.key}); @override State<Home> createState()=>_HomeState(); }
class _HomeState extends State<Home>{
  int tab=0; final history=<String>[];
  @override void initState(){super.initState(); _load();}
  Future<void> _load() async {final p=await SharedPreferences.getInstance();setState(()=>history.addAll(p.getStringList('history')??[]));}
  Future<void> _record(String s) async {history.insert(0,s);final p=await SharedPreferences.getInstance();await p.setStringList('history',history.take(30).toList());setState((){});}
  @override Widget build(BuildContext c){
    final pages=[ProtectPage(onResult:_record),const RecoveryPage(),HistoryPage(history:history)];
    return Scaffold(appBar:AppBar(title:const Text('🛡️ ScamShield')),
      body:pages[tab],
      bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(i)=>setState(()=>tab=i),
        destinations:const[
          NavigationDestination(icon:Icon(Icons.shield_outlined),selectedIcon:Icon(Icons.shield),label:'Protect'),
          NavigationDestination(icon:Icon(Icons.emergency_outlined),selectedIcon:Icon(Icons.emergency),label:'Recovery'),
          NavigationDestination(icon:Icon(Icons.history),label:'Cases')]));
  }
}

class ProtectPage extends StatelessWidget {
  final Future<void> Function(String) onResult; const ProtectPage({super.key,required this.onResult});
  void input(BuildContext c,String type,String title,String hint) {
    final ctl=TextEditingController();
    showModalBottomSheet(context:c,isScrollControlled:true,builder:(_)=>Padding(
      padding:EdgeInsets.fromLTRB(18,18,18,MediaQuery.of(c).viewInsets.bottom+18),
      child:Column(mainAxisSize:MainAxisSize.min,children:[
        Text(title,style:Theme.of(c).textTheme.headlineSmall),const SizedBox(height:12),
        TextField(controller:ctl,maxLines:type=='message'?7:2,decoration:InputDecoration(hintText:hint,border:const OutlineInputBorder())),
        const SizedBox(height:12),FilledButton(onPressed:()async{
          Navigator.pop(c); final r=await analyze(type,ctl.text);
          await onResult('$type|${r.title}|${DateTime.now()}');
          if(c.mounted) Navigator.push(c,MaterialPageRoute(builder:(_)=>ResultPage(r)));
        },child:const Text('Analyze'))])));
  }
  @override Widget build(BuildContext c){
    final items=[
      ('Phone',Icons.phone,'phone','Enter phone number'),
      ('Message',Icons.message,'message','Paste SMS/WhatsApp message'),
      ('Link',Icons.link,'url','Paste website link'),
      ('UPI',Icons.account_balance_wallet,'upi','Enter UPI ID')];
    return ListView(padding:const EdgeInsets.all(16),children:[
      Card(child:Padding(padding:const EdgeInsets.all(18),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text('Protect your identity & money',style:Theme.of(c).textTheme.headlineSmall),
        const SizedBox(height:8),const Text('Check before you trust, share or pay. ScamShield never asks for OTPs, PINs or passwords.')
      ]))),
      const SizedBox(height:12),
      GridView.builder(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),
        gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:2,crossAxisSpacing:10,mainAxisSpacing:10),
        itemCount:items.length+1,itemBuilder:(_,i){
          if(i==items.length)return Card(child:InkWell(onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>const QRPage())),
            child:const Column(mainAxisAlignment:MainAxisAlignment.center,children:[Icon(Icons.qr_code_scanner,size:38),SizedBox(height:8),Text('Scan QR')])));
          final x=items[i];return Card(child:InkWell(onTap:()=>input(c,x.$3,x.$1,x.$4),
            child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Icon(x.$2,size:36),const SizedBox(height:8),Text(x.$1)])));
        }),
      const SizedBox(height:14),
      OutlinedButton.icon(onPressed:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>const DataPage())),
        icon:const Icon(Icons.lock),label:const Text('Personal data protection'))
    ]);
  }
}

class ResultPage extends StatelessWidget{
  final Result r; const ResultPage(this.r,{super.key});
  @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Risk result')),body:ListView(padding:const EdgeInsets.all(20),children:[
    Icon(r.risk==Risk.high?Icons.dangerous:r.risk==Risk.suspicious?Icons.warning:Icons.check_circle,size:82),
    const SizedBox(height:12),Center(child:Text(r.title,style:Theme.of(c).textTheme.headlineMedium)),
    const SizedBox(height:10),Text(r.explanation,textAlign:TextAlign.center),
    const SizedBox(height:20),Text('Indicators',style:Theme.of(c).textTheme.titleLarge),
    ...r.reasons.map((x)=>ListTile(leading:const Icon(Icons.chevron_right),title:Text(x))),
    const Card(child:Padding(padding:EdgeInsets.all(16),child:Text('Never share OTP, UPI PIN, CVV, card PIN or banking passwords.')))]));
}

class QRPage extends StatefulWidget{const QRPage({super.key});@override State<QRPage>createState()=>_QRPageState();}
class _QRPageState extends State<QRPage>{bool scanned=false;
 @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Scan QR safely')),body:scanned
 ?const Center(child:Text('QR captured. Review its destination before opening or paying.'))
 :MobileScanner(onDetect:(capture)async{
   if(scanned)return;if(capture.barcodes.isEmpty)return;
   final v=capture.barcodes.first.rawValue;if(v==null || v.isEmpty)return;
   setState(()=>scanned=true);final r=await analyze('url',v);
   if(c.mounted)Navigator.push(c,MaterialPageRoute(builder:(_)=>ResultPage(r)));
 }) );
}

class RecoveryPage extends StatelessWidget{const RecoveryPage({super.key});
 Future<void> portal()async=>launchUrl(Uri.parse('https://www.cybercrime.gov.in/'),mode:LaunchMode.externalApplication);
 @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[
  Text('Fraud recovery',style:Theme.of(c).textTheme.headlineSmall),const SizedBox(height:8),
  const Text('Act quickly. ScamShield helps you preserve evidence and follow legitimate recovery channels; it cannot access or take money from another person’s account.'),
  const SizedBox(height:12),
  ...const[
   ('1','Stop','Do not send more money or disclose OTP/PIN/CVV.'),
   ('2','Call your bank','Use the official bank/payment-provider app or number and ask about blocking/disputing the transaction.'),
   ('3','Preserve evidence','Keep screenshots, chats, phone numbers, URLs, UPI IDs, transaction IDs and timestamps.'),
   ('4','Report','Use the official cybercrime reporting channel and your bank/payment provider promptly.'),
   ('5','Secure accounts','Change compromised passwords and revoke unknown sessions; contact your carrier if SIM compromise is suspected.')
  ].map((x)=>Card(child:ListTile(leading:CircleAvatar(child:Text(x.$1)),title:Text(x.$2),subtitle:Text(x.$3)))),
  const SizedBox(height:8),FilledButton.icon(onPressed:portal,icon:const Icon(Icons.open_in_new),label:const Text('India Cyber Crime portal'))]);
}

class HistoryPage extends StatelessWidget{final List<String> history;const HistoryPage({super.key,required this.history});
 @override Widget build(BuildContext c)=>history.isEmpty?const Center(child:Text('No cases yet.')):ListView.builder(itemCount:history.length,itemBuilder:(_,i)=>ListTile(leading:const Icon(Icons.shield),title:Text(history[i])));}

class DataPage extends StatelessWidget{const DataPage({super.key});
 @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Protect personal details')),body:ListView(padding:const EdgeInsets.all(18),children:const[
  Text('Never share',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold)),SizedBox(height:10),
  Text('OTP / verification codes\\nUPI PIN\\nCard/ATM PIN\\nCVV\\nBanking passwords\\nRecovery codes'),
  SizedBox(height:22),Text('Verify independently',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold)),SizedBox(height:10),
  Text('If someone claims to be from a bank, police, delivery company or government service, contact the organization through its official app, website or number you already trust.'),
  SizedBox(height:22),Text('ScamShield privacy',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold)),SizedBox(height:10),
  Text('V2 is designed for data minimization. A production backend should encrypt evidence, enforce access control and provide deletion controls.')
 ]);}
}
