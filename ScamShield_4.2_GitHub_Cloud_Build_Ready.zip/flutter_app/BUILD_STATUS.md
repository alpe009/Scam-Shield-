# ScamShield 4.2 signing/build status

A new RSA-4096 upload keystore has been generated for ScamShield 4.2.

The Flutter project has been configured to load `android/key.properties` and sign the release variant when that file is present.

## Important
The current execution environment does not contain the Flutter SDK and cannot download it, so a genuine ScamShield `.aab` could not be compiled here. No fake or placeholder `.aab` was produced.

Use Flutter stable 3.47.4 (Dart 3.13.3) or a newer compatible stable release, then run:

    flutter pub get
    flutter build appbundle --release

The signed bundle will be generated under:

    build/app/outputs/bundle/release/app-release.aab

Google Play's recommended model is to use this local key as the upload key and let Play App Signing manage the app-signing/distribution key.
