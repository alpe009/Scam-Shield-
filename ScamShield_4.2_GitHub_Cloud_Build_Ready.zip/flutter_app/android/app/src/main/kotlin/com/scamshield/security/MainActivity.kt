package com.scamshield.security

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
