# ScamShield release rules. Keep empty unless Flutter/plugin diagnostics require additional rules.
